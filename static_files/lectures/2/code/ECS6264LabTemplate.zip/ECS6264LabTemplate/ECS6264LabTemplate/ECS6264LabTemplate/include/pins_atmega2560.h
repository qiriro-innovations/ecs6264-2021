/*
 * pins_atmega2560.h
 *
 * Created: 9/28/2021 5:45:35 PM
 *  Author: qiriro
 */ 


#ifndef PINS_ATMEGA2560_H_
#define PINS_ATMEGA2560_H_


// Port A
#define IO22 PA0
#define IO23 PA1
#define IO24 PA2
#define IO25 PA3
#define IO26 PA4
#define IO27 PA5
#define IO28 PA6
#define IO29 PA7

// Port B
#define IO53 PB0
#define IO52 PB1
#define IO51 PB2
#define IO50 PB3
#define IO10 PB4
#define IO11 PB5
#define IO12 PB6
#define IO13 PB7

// Port C
#define IO37 PC0
#define IO36 PC1
#define IO35 PC2
#define IO34 PC3
#define IO33 PC4
#define IO32 PC5
#define IO31 PC6
#define IO30 PC7

// Port D
#define IO21 PD0
#define IO20 PD1
#define IO19 PD2
#define IO18 PD3
#define IO38 PD7

// Port E
#define IO0 PE0
#define IO1 PE1
#define IO5 PE3
#define IO2 PE4
#define IO3 PE5

// Port F
#define ADO PF0
#define AD1 PF1
#define AD2 PF2
#define AD3 PF3
#define AD4 PF4
#define AD5 PF5
#define AD6 PF6
#define AD7 PF7





#endif /* PINS_ATMEGA2560_H_ */