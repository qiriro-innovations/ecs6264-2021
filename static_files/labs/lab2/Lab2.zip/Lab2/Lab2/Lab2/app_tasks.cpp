/*
 * app_tasks.c
 *
 * Created: 11/23/2020 5:03:34 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 
#include <stdbool.h> // For true and false
#include <avr/io.h>
#define F_CPU 16000000UL //XTAL frequency = 16MHz
#include <util/delay.h>
#include <Arduino.h>
#include <LiquidCrystal.h>
#include "Arduino_FreeRTOS.h"
#include "include/app_tasks.h"
#include "include/board.h"
#include "include/util.h"
#include "include/stack_size.h"
#include "include/priorities.h"


// Global variables
TaskHandle_t xRedLedHandle=NULL;
TaskHandle_t xYellowLedHandle=NULL;
TaskHandle_t xBuiltinLedHandle=NULL;
bool clear_lcd =false;
void vLcdTask(void *pvParameters __attribute__((unused)))
{
	// The LCD uses the standard arduino lcd display 
	// See https://www.arduino.cc/en/Reference/LiquidCrystal
	const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
	LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
	 // set up the LCD's number of columns and rows:
	lcd.begin(16, 2);
	while(true)
	{
		// set the cursor to (0,0):
		lcd.setCursor(0, 0);
		// print from 0 to 9:
		for (int thisChar = 0; thisChar < 10; thisChar++) {
			lcd.print(thisChar);
			delay(500);
		}

		// set the cursor to (16,1):
		lcd.setCursor(16, 1);
		// set the display to automatically scroll:
		lcd.autoscroll();
		// print from 0 to 9:
		for (int thisChar = 0; thisChar < 10; thisChar++) {
			lcd.print(thisChar);
			delay(500);
		}
		// turn off automatic scrolling
		lcd.noAutoscroll();

		// clear screen for the next loop:
		lcd.clear();
	}
	vTaskDelete( NULL );
}

void vYellowLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	LED_DDR |= (1<<LED_YELLOW);
	while(true)
	{
		LED_PORT ^= (1<<LED_YELLOW);
		os_delay_ms(500);
		
	}
	/*  Tasks must not attempt to return from their implementing
        function or otherwise exit.  In newer FreeRTOS port
        attempting to do so will result in an configASSERT() being
        called if it is defined.  If it is necessary for a task to
        exit then have the task call vTaskDelete( NULL ) to ensure
        its exit is clean. 
	*/
        vTaskDelete( NULL );
}
void vRedLedTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	LED_DDR |= (1<<LED_RED); 	
	while(true)
	{
		LED_PORT ^= (1<<LED_RED);
		os_delay_ms(500);
	}
	 vTaskDelete( NULL );
}
void vStatusTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	LED_DDR |= (1<<LED_BUILTIN);
	while(true)
	{
		LED_PORT ^= (1<<LED_BUILTIN);
		os_delay_ms(1000);
	}
	vTaskDelete( NULL );
}

void os_init()
{
	// Setup the task to blink the yellow led
	xTaskCreate(vYellowLedTask, "Y-led",OS_MINIMUM_STACK_SIZE, NULL,OS_PRIORITY_LOW,  &xYellowLedHandle);
	// Setup the task to blink the green led
	xTaskCreate(vRedLedTask,"R-led",OS_MINIMUM_STACK_SIZE,NULL,OS_PRIORITY_LOW, &xRedLedHandle);
	// Setup the task to status led
	xTaskCreate(vStatusTask,"status task",OS_MINIMUM_STACK_SIZE,NULL,OS_PRIORITY_LOWEST,&xBuiltinLedHandle);
	xTaskCreate(vLcdTask,"LCD",OS_EXTRA_LARGE_STACK_SIZE,NULL,OS_PRIORITY_LOWEST,NULL);
	
	// Start scheduler.
	vTaskStartScheduler();
	
}
void vApplicationIdleHook(){}
void vApplicationTickHook(){}
void vApplicationAssertHook(){}
void vApplicationMallocFailedHook(){}
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcTaskName ){}