﻿#include <Arduino_FreeRTOS.h>
#include <Arduino.h>
#include "board.h"
#include "app_tasks.h"


void setup() {
   // initialize serial communication at 9600 bits per second:
  Serial.begin(9600);
  
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB, on LEONARDO, MICRO, YUN, and other 32u4 based boards.
  }
 os_init();
}

void loop()
{

}
