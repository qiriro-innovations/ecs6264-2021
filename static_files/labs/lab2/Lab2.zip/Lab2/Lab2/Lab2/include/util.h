/*
 * util.h
 *
 * Created: 11/23/2020 4:24:38 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef UTIL_H_
#define UTIL_H_
#include <avr/io.h>
void os_delay_ms(const long ms);
void blocking_delay_ms(long ms);


#endif /* UTIL_H_ */