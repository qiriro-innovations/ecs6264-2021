/*
 * stack_size.h
 *
 * Created: 11/23/2020 4:29:02 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef STACK_SIZE_H_
#define STACK_SIZE_H_
//
//-----------------------------------------------------------------------------------
//
// Define task stack sizes
#define  OS_MINIMUM_STACK_SIZE       (configMINIMAL_STACK_SIZE) 
#define  OS_LOW_STACK_SIZE           (OS_MINIMUM_STACK_SIZE * 2)
#define  OS_MEDIUM_STACK_SIZE        (OS_LOW_STACK_SIZE * 2)
#define  OS_LARGE_STACK_SIZE         (OS_MEDIUM_STACK_SIZE * 2)
#define  OS_EXTRA_LARGE_STACK_SIZE   (OS_LARGE_STACK_SIZE * 2)


#endif /* STACK_SIZE_H_ */