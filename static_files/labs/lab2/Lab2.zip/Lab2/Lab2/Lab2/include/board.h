/*
 * pin_definitions.h
 *
 * Created: 11/23/2020 4:32:51 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef BOARD_H_
#define BOARD_H_
#include "pins_atmega2560.h"
// Switch
#define SWITCH_STOP      IO10
#define SWITCH_PORT      PORTB
// LED peripherals
#define LED_RED          IO51
#define LED_YELLOW       IO50
#define LED_BUILTIN      IO13 
#define LED_PORT         PORTB 
#define LED_DDR          DDRB 
// LCD Display 
#define LCD_RS               IO12
#define LCD_EN               IO11
#define LCD_D4               IO5
#define LCD_D5               IO4
#define LCD_D6               IO3
#define LCD_D7               IO2
// The 4-bit DIP switches
#define DIP_SWITCH_PORT      PORTA
#define DIP_SWITCH_DDR       DDRA 
#define DIP_SW1_PIN1         IO22
#define DIP_SW1_PIN2         IO23
#define DIP_SW1_PIN3         IO24
#define DIP_SW1_PIN4         IO25


#endif /* BOARD_H_ */