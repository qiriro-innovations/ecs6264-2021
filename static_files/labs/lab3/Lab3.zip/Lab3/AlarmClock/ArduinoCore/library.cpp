/*
 * ArduinoCore.cpp
 *
 * Created: 10/4/2021 8:22:31 PM
 * Author : qiriro
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

