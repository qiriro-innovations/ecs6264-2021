/*
 * app_tasks.c
 *
 * Created: 11/23/2020 5:03:34 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 
#include <stdbool.h> // For true and false
#include <avr/io.h>
#define F_CPU 16000000UL //XTAL frequency = 16MHz
#include <util/delay.h>
#include <Arduino.h>
#include <LiquidCrystal.h>
#include "Arduino_FreeRTOS.h"
#include "include/app_tasks.h"
#include "include/board.h"
#include "include/util.h"
#include "include/stack_size.h"
#include "include/priorities.h"


void vStatusTask(void *pvParameters __attribute__((unused)) )
{
	// Se the LED_PIN an output
	LED_DDR |= (1<<LED_BUILTIN);
	while(true)
	{
		LED_PORT ^= (1<<LED_BUILTIN);
		os_delay_ms(1000);
	}
	vTaskDelete( NULL );
}

void os_init()
{
	// TODO: setup other tasks
	xTaskCreate(vStatusTask,"status task",OS_MINIMUM_STACK_SIZE,NULL,OS_PRIORITY_LOWEST,NULL);	
	// Start scheduler.
	vTaskStartScheduler();
	
}
void vApplicationIdleHook(){}
void vApplicationTickHook(){}
void vApplicationAssertHook(){}
void vApplicationMallocFailedHook(){}
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcTaskName ){}