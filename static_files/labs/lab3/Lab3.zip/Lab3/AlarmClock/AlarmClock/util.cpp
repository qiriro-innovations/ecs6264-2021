/*
 * util.c
 *
 * Created: 11/23/2020 4:43:11 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 
#include <Arduino_FreeRTOS.h>
#ifndef F_CPU
#define F_CPU 16000000UL
#endif
#include <avr/io.h>
#include <util/delay.h>
#include "include/util.h"

void os_delay_ms(const long ms)
{
	vTaskDelay( ms / portTICK_PERIOD_MS ); 
}
void blocking_delay_ms(long ms)
{   
	/*
	Note: 
	This method is not as accurate as directly calling _delay_ms(ms), which is not feasible 
	because _delay_ms(ms) expects a compile time integer constant and would not compile otherwise.
	However, for the sake of this lab exercise, the method will work reasonably well. 
	*/
	while (0 < ms)
	{
		_delay_ms(1);
		--ms;
	}
}
