/*
 * pin_definitions.h
 *
 * Created: 11/23/2020 4:32:51 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef BOARD_H_
#define BOARD_H_
#include "pins_atmega2560.h"

// LED peripherals
#define LED_BUILTIN      IO13 
#define LED_PORT         PORTB 
#define LED_DDR          DDRB 

#endif /* BOARD_H_ */