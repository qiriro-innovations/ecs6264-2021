/*
 * priorities.h
 *
 * Created: 11/23/2020 4:26:25 PM
 *  Author: Kizito NKURIKIYEYEZU
 */ 


#ifndef PRIORITIES_H_
#define PRIORITIES_H_

// Define task priorities
//-----------------------------------------------------------------------------------
//
///< priority: idle (lowest)
#define OS_PRIORITY_LOWEST                 tskIDLE_PRIORITY
#define OS_PRIORITY_LOW                  (OS_PRIORITY_LOWEST+1)
#define OS_PRIORITY_NORMAL               (OS_PRIORITY_LOW + 1) 
#define OS_PRIORITY_HIGHEST              (configMAX_PRIORITIES-1)

#endif /* PRIORITIES_H_ */